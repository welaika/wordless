var searchData=
[
  ['wordless',['Wordless',['../dc/dc0/namespaceWordless.html',1,'']]]
];
