var searchData=
[
  ['_5f_5fcall',['__call',['../d2/d64/classMobile__Detect.html#ac91af2f48a2b0e44057be717b72562b0',1,'Mobile_Detect']]],
  ['_5f_5fconstruct',['__construct',['../da/d93/classCycle.html#a7b34e2d731b3d7cc548130cf0d668fb2',1,'Cycle\__construct()'],['../d2/d64/classMobile__Detect.html#a5ba4cc5ceba9d7a15209e3a566e99281',1,'Mobile_Detect\__construct()']]]
];
