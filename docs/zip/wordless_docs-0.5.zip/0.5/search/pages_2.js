var searchData=
[
  ['placeholder_20services',['Placeholder Services',['../db/da1/placeholderservices.html',1,'']]]
];
