var searchData=
[
  ['value',['value',['../da/d93/classCycle.html#a00e29fd7825ff6b5df409fe612a11f71',1,'Cycle']]],
  ['values',['values',['../da/d93/classCycle.html#a37fc799a1619bbf4c429423760dd3b58',1,'Cycle']]],
  ['vendor_20helpers_20classes',['Vendor Helpers Classes',['../d4/d1a/group__vendorclass.html',1,'']]],
  ['ver',['VER',['../d2/d64/classMobile__Detect.html#ab34e9d2a32002b0e8ecd28d0931e7967',1,'Mobile_Detect']]],
  ['version',['VERSION',['../d2/d64/classMobile__Detect.html#aa11d8676a149e0236e4228a8ed42a0cf',1,'Mobile_Detect\VERSION()'],['../d2/d64/classMobile__Detect.html#a393a3b89ebce61532bf76f7da5ff5a7f',1,'Mobile_Detect\version($propertyName, $type=self::VERSION_TYPE_STRING)']]],
  ['version_5ftype_5ffloat',['VERSION_TYPE_FLOAT',['../d2/d64/classMobile__Detect.html#a147c371be440ada6c9556336fdd6c842',1,'Mobile_Detect']]],
  ['version_5ftype_5fstring',['VERSION_TYPE_STRING',['../d2/d64/classMobile__Detect.html#a5bd989fccb0f40f04605b5cd10d4084c',1,'Mobile_Detect']]],
  ['video_5ftag',['video_tag',['../dd/d16/group__helperfunc.html#gaea8c5d93735aae9dfec10657b1152fbf',1,'AssetTagHelper']]]
];
