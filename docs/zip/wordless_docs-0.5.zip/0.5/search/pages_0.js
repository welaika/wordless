var searchData=
[
  ['code_20doubts',['Code Doubts',['../d0/d93/doubt.html',1,'']]]
];
