var searchData=
[
  ['ver',['VER',['../d2/d64/classMobile__Detect.html#ab34e9d2a32002b0e8ecd28d0931e7967',1,'Mobile_Detect']]],
  ['version',['VERSION',['../d2/d64/classMobile__Detect.html#aa11d8676a149e0236e4228a8ed42a0cf',1,'Mobile_Detect']]],
  ['version_5ftype_5ffloat',['VERSION_TYPE_FLOAT',['../d2/d64/classMobile__Detect.html#a147c371be440ada6c9556336fdd6c842',1,'Mobile_Detect']]],
  ['version_5ftype_5fstring',['VERSION_TYPE_STRING',['../d2/d64/classMobile__Detect.html#a5bd989fccb0f40f04605b5cd10d4084c',1,'Mobile_Detect']]]
];
