var searchData=
[
  ['queryhelper',['QueryHelper',['../da/d43/classQueryHelper.html',1,'']]]
];
