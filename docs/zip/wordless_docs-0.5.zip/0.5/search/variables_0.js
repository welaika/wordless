var searchData=
[
  ['detection_5ftype_5fextended',['DETECTION_TYPE_EXTENDED',['../d2/d64/classMobile__Detect.html#a0fa1be8f0cf450b2564a9794f07c87ae',1,'Mobile_Detect']]],
  ['detection_5ftype_5fmobile',['DETECTION_TYPE_MOBILE',['../d2/d64/classMobile__Detect.html#a033aff0e54d0bc7752a0bcfd7d04c17e',1,'Mobile_Detect']]]
];
