var searchData=
[
  ['match',['match',['../d2/d64/classMobile__Detect.html#a3c85e8052cf6fa0b13a9e4fa8f116eb7',1,'Mobile_Detect']]],
  ['matchdetectionrulesagainstua',['matchDetectionRulesAgainstUA',['../d2/d64/classMobile__Detect.html#ae98769bac1343701f8a38892a7a3cc69',1,'Mobile_Detect']]],
  ['matchuaagainstkey',['matchUAAgainstKey',['../d2/d64/classMobile__Detect.html#a90c81acc7257d364ef041974d2b1dc33',1,'Mobile_Detect']]],
  ['mobilegrade',['mobileGrade',['../d2/d64/classMobile__Detect.html#a308a9203a8d215c3528e51b74afaa580',1,'Mobile_Detect']]]
];
