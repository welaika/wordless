var searchData=
[
  ['mobile_5fgrade_5fa',['MOBILE_GRADE_A',['../d2/d64/classMobile__Detect.html#a9b7181141ab6dc44cc26baffa193290f',1,'Mobile_Detect']]],
  ['mobile_5fgrade_5fb',['MOBILE_GRADE_B',['../d2/d64/classMobile__Detect.html#a9d9fcd475396591a3cb65916af5ac620',1,'Mobile_Detect']]],
  ['mobile_5fgrade_5fc',['MOBILE_GRADE_C',['../d2/d64/classMobile__Detect.html#afd3699f69d34bcc731171ecf20b481cc',1,'Mobile_Detect']]]
];
