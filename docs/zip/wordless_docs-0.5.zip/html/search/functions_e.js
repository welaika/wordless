var searchData=
[
  ['setdetectiontype',['setDetectionType',['../d2/d64/classMobile__Detect.html#a63fc0d44e408f658863492da67792f6c',1,'Mobile_Detect']]],
  ['sethttpheaders',['setHttpHeaders',['../d2/d64/classMobile__Detect.html#ac67ce9839361c74d22ab43c76e44eba5',1,'Mobile_Detect']]],
  ['setuseragent',['setUserAgent',['../d2/d64/classMobile__Detect.html#aeac0a4ee935cd7057649d67f9c8eaa93',1,'Mobile_Detect']]],
  ['simple_5ffields_5fmeta',['simple_fields_meta',['../dd/df3/classSimpleFieldsHelper.html#a5d0b36cbbb24c12467069b91621f9047',1,'SimpleFieldsHelper']]],
  ['simple_5ffields_5fmetas',['simple_fields_metas',['../dd/df3/classSimpleFieldsHelper.html#aadb8f973157df64f01d35e00505f1093',1,'SimpleFieldsHelper']]],
  ['stylesheet_5flink_5ftag',['stylesheet_link_tag',['../dd/d16/group__helperfunc.html#ga3d7cd3406c3065bf9c45affdd339888e',1,'AssetTagHelper']]],
  ['stylesheet_5furl',['stylesheet_url',['../dd/d16/group__helperfunc.html#ga65c283fa91fd4801187737bf3f3b1e78',1,'UrlHelper']]]
];
