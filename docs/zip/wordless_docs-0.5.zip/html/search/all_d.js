var searchData=
[
  ['pingback_5flink_5ftag',['pingback_link_tag',['../de/db9/classTagHelper.html#ab04ff7f76f7225b8b6bf6d97c48b1562',1,'TagHelper']]],
  ['placeholder_5fimage',['placeholder_image',['../dd/d16/group__helperfunc.html#gada45e49febcaab091e48ce00650eb3c0',1,'FakerHelper']]],
  ['placeholder_5ftext',['placeholder_text',['../dd/d16/group__helperfunc.html#ga6fea140a41a3690d1633ac0b95d59f91',1,'FakerHelper']]],
  ['placeholder_20services',['Placeholder Services',['../db/da1/placeholderservices.html',1,'']]],
  ['pluralize',['pluralize',['../dd/d16/group__helperfunc.html#ga15593432b0126a0392b49e0ebf93a5bf',1,'TextHelper']]],
  ['prepareversionno',['prepareVersionNo',['../d2/d64/classMobile__Detect.html#aea41d995a222b270d4dcc89871cbda18',1,'Mobile_Detect']]]
];
