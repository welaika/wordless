var searchData=
[
  ['match',['match',['../d2/d64/classMobile__Detect.html#a3c85e8052cf6fa0b13a9e4fa8f116eb7',1,'Mobile_Detect']]],
  ['matchdetectionrulesagainstua',['matchDetectionRulesAgainstUA',['../d2/d64/classMobile__Detect.html#ae98769bac1343701f8a38892a7a3cc69',1,'Mobile_Detect']]],
  ['matchuaagainstkey',['matchUAAgainstKey',['../d2/d64/classMobile__Detect.html#a90c81acc7257d364ef041974d2b1dc33',1,'Mobile_Detect']]],
  ['mediahelper',['MediaHelper',['../de/ded/classMediaHelper.html',1,'']]],
  ['mobile_5fdetect',['Mobile_Detect',['../d2/d64/classMobile__Detect.html',1,'']]],
  ['mobile_5fgrade_5fa',['MOBILE_GRADE_A',['../d2/d64/classMobile__Detect.html#a9b7181141ab6dc44cc26baffa193290f',1,'Mobile_Detect']]],
  ['mobile_5fgrade_5fb',['MOBILE_GRADE_B',['../d2/d64/classMobile__Detect.html#a9d9fcd475396591a3cb65916af5ac620',1,'Mobile_Detect']]],
  ['mobile_5fgrade_5fc',['MOBILE_GRADE_C',['../d2/d64/classMobile__Detect.html#afd3699f69d34bcc731171ecf20b481cc',1,'Mobile_Detect']]],
  ['mobilegrade',['mobileGrade',['../d2/d64/classMobile__Detect.html#a308a9203a8d215c3528e51b74afaa580',1,'Mobile_Detect']]],
  ['modelhelper',['ModelHelper',['../d2/d17/classModelHelper.html',1,'']]]
];
