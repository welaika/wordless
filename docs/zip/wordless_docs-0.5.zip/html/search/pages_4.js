var searchData=
[
  ['wordless_2c_20don_27t_20waste_20words_20on_20wordpress_21',['Wordless, don&apos;t waste words on wordpress!',['../index.html',1,'']]]
];
