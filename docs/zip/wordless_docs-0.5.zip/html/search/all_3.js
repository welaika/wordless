var searchData=
[
  ['datehelper',['DateHelper',['../d2/d25/classDateHelper.html',1,'']]],
  ['debughelper',['DebugHelper',['../d3/d47/classDebugHelper.html',1,'']]],
  ['deprecated_20list',['Deprecated List',['../da/d58/deprecated.html',1,'']]],
  ['detect_5fuser_5fagent',['detect_user_agent',['../dd/d16/group__helperfunc.html#ga54c1036bb1d1ecacfa094e032b1c7830',1,'MediaHelper']]],
  ['detection_5ftype_5fextended',['DETECTION_TYPE_EXTENDED',['../d2/d64/classMobile__Detect.html#a0fa1be8f0cf450b2564a9794f07c87ae',1,'Mobile_Detect']]],
  ['detection_5ftype_5fmobile',['DETECTION_TYPE_MOBILE',['../d2/d64/classMobile__Detect.html#a033aff0e54d0bc7752a0bcfd7d04c17e',1,'Mobile_Detect']]],
  ['distance_5fof_5ftime_5fin_5fwords',['distance_of_time_in_words',['../dd/d16/group__helperfunc.html#gae4aa380ddfb20eedbc8e346658a709f6',1,'DateHelper']]],
  ['dump',['dump',['../dd/d16/group__helperfunc.html#ga1c65ba8e58591dabdf0cef86fc054c8f',1,'DebugHelper']]]
];
